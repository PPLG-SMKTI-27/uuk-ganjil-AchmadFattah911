<?php
require_once __DIR__ . "/../../Config/database.php";

class TempatParkir {
    private $conn;
    private $table = "tempatparkir";

    public function __construct(){
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function masuk($id_kendaraan,$id_user){
        // hitung biaya
        $queryKendaraan = "SELECT jk FROM kendaraan WHERE id=:id";
        $stmt = $this->conn->prepare($queryKendaraan);
        $stmt->bindParam(":id",$id_kendaraan);
        $stmt->execute();
        $jk = $stmt->fetch(PDO::FETCH_ASSOC)['jk'];
        $biaya = ($jk=='motor')?5000:10000;

        $query = "INSERT INTO {$this->table} (id_kendaraan,id_user,biaya,status) VALUES (:id_kendaraan,:id_user,:biaya,'dalamParkiran')";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id_kendaraan",$id_kendaraan);
        $stmt->bindParam(":id_user",$id_user);
        $stmt->bindParam(":biaya",$biaya);
        return $stmt->execute();
    }

    public function keluar($id){
        $query = "UPDATE {$this->table} SET jam_keluar=NOW(), status='Pembayaran' WHERE id=:id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id",$id);
        return $stmt->execute();
    }

    public function konfirmasi($id){
        $query = "UPDATE {$this->table} SET status='telahDiKonfirmasi' WHERE id=:id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id",$id);
        return $stmt->execute();
    }

    public function getAll(){
        $query = "SELECT tp.*,k.no_plat,k.jk,u.username FROM {$this->table} tp
                  LEFT JOIN kendaraan k ON tp.id_kendaraan=k.id
                  LEFT JOIN users u ON tp.id_user=u.id
                  ORDER BY tp.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function totalharga() {
        $query = "SELECT SUM(biaya) AS 'Total' FROM tempatparkir";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
