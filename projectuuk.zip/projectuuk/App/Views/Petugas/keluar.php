<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kendaraan Keluar</title>
    <link href="../../Public/asset/output.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">

    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl">
        <h2 class="text-2xl font-bold mb-6 text-center text-gray-800">Kendaraan Keluar</h2>

        <?php if (empty($data)): ?>
            <p class="text-center text-gray-600">Tidak ada kendaraan yang sedang diparkir.</p>
        <?php else: ?>
            <table class="w-full text-sm text-left mb-6">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="px-4 py-2">No. Plat</th>
                        <th class="px-4 py-2">Jenis</th>
                        <th class="px-4 py-2">Masuk</th>
                        <th class="px-4 py-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $p): ?>
                        <?php if (is_null($p['waktu_keluar'])): // hanya kendaraan yang belum keluar ?>
                            <tr class="bg-gray-50">
                                <td class="px-4 py-2"><?= htmlspecialchars($p['no_plat']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($p['jenis']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($p['waktu_masuk']) ?></td>
                                <td class="px-4 py-2">
                                    <a href="index.php?action=keluar_kendaraan&id=<?= $p['id_parkir'] ?>"
                                       class="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-400 transition">
                                        Tandai Keluar
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <a href="index.php?action=dashboard_petugas" 
           class="w-full block text-center bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-500 transition duration-200">
            Kembali ke Dashboard
        </a>
    </div>

</body>
</html>
