/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./App/Views/**/*.{php,html}",
    "./Public/**/*.php"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
