<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Petugas</title>
    <link href="../../Public/asset/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen p-6">
    <h1 class="text-3xl font-bold mb-6">Dashboard Petugas</h1>

    <a href="index.php?action=masuk_kendaraan" 
        class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-400 transition mb-4 inline-block">
        Tambah Kendaraan Masuk
    </a>

    <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden mt-4">
        <thead class="bg-gray-200">
            <tr>
                <th class="py-2 px-4 text-left">No Plat</th>
                <th class="py-2 px-4 text-left">Jenis</th>
                <th class="py-2 px-4 text-left">Jam Masuk</th>
                <th class="py-2 px-4 text-left">Status</th>
                <th class="py-2 px-4 text-left">Biaya</th>
                <th class="py-2 px-$ text-left">Aksi</th>
                <th class="py-2 px-$ text-left">TotalHarga</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data as $parkir): ?>
                <tr class="border-b hover:bg-gray-100">
                    <td class="py-2 px-4"><?= $parkir['no_plat'] ?></td>
                    <td class="py-2 px-4"><?= ucfirst($parkir['jk']) ?></td>
                    <td class="py-2 px-4"><?= $parkir['jam_masuk'] ?></td>
                    <td class="py-2 px-4"><?= $parkir['status'] ?></td>
                    <td class="py-2 px-4"><?= $parkir['biaya'] ?></td>
                    <td class="py-2 px-4 space-x-2">
                        <?php if($parkir['status'] === 'dalamParkiran'): ?>
                            <a href="index.php?action=keluar_kendaraan&id=<?= $parkir['id'] ?>" 
                                class="px-2 py-1 bg-yellow-400 text-white rounded hover:bg-yellow-300 transition">Keluar</a>
                        <?php endif; ?>
                        </td>
            <?php endforeach; ?>
                <td><?= $TotalHarga['Total'] ?></td>
                </tr>
        </tbody>
    </table>
</body>
</html>