<?php
require_once __DIR__ . "/Config/database.php";

$db = new Database();
$conn = $db->getConnection();

// Data akun
$users = [
    [
        'username' => 'admin',
        'email' => 'admin@example.com',
        'password' => password_hash('admin123', PASSWORD_DEFAULT),
        'role' => 'admin'
    ],
    [
        'username' => 'petugas',
        'email' => 'petugas@example.com',
        'password' => password_hash('petugas123', PASSWORD_DEFAULT),
        'role' => 'petugasloket'
    ]
];

foreach ($users as $user) {
    $sql = "INSERT INTO users (username, email, password, role) VALUES (:username, :email, :password, :role)";
    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':username', $user['username']);
    $stmt->bindParam(':email', $user['email']);
    $stmt->bindParam(':password', $user['password']);
    $stmt->bindParam(':role', $user['role']);

    if ($stmt->execute()) {
        echo "Akun {$user['username']} berhasil ditambahkan!<br>";
    } else {
        echo "Gagal menambahkan akun {$user['username']}<br>";
    }
}
