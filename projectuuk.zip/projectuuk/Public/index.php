    <?php
    session_start();

    require_once __DIR__.'/../App/Controller/UserController.php';
    require_once __DIR__.'/../App/Controller/ParkirController.php';


    $userController = new UserController();
    $parkirController = new ParkirController();

    $action = $_GET['action'] ?? 'login';

    switch($action){

    // Login/Register Section
        case 'login': 
            $userController->login(); 
            break;
        case 'register': 
            $userController->register();
            break;

    // Dashboard admin
        // Dashboard admin
        case 'dashboard_admin': 
            $userController->index(); 
            break;
        case 'store_user':
            $userController->store();
            break;
        case 'create_user':
            $userController->create(); 
            break;
        case 'update_user';
            $userController->update();
        case 'edit_user':
            $userController->edit(); 
            break;
        case 'delete_user':
            $userController->delete(); 
            break;


    // Dasboard Petugas
        case 'dashboard_petugas':
            $parkirController->dashboardPetugas(); 
            break;
        case 'masuk_kendaraan': 
            $parkirController->masuk(); 
            break;
        case 'keluar_kendaraan': 
            $parkirController->keluar(); 
            break;
        case 'konfirmasi': 
            $parkirController->konfirmasi(); 
            break;

    // Logout
        case 'logout':
            session_destroy();
            header("Location:index.php?action=login");
            break;
            
    // Error
        default: echo "404 Page Not Found"; break;
    }
