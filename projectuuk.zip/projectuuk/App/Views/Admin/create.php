<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Pegawai Baru</title>
    <link href="/../projectuuk/Public/asset/output.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
    <form action="index.php?action=store_user" method="POST"
        class="bg-indigo-50 p-8 rounded-lg shadow-lg w-full max-w-sm">

        <h2 class="text-2xl font-bold mb-6 text-center text-gray-800">Membuat Akun Petugas</h2>

        <div class="mb-4">
            <input type="text" name="username" placeholder="Username"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
        </div>

        <div class="mb-4">
            <input type="email" name="email" placeholder="Email"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
        </div>

        <div class="mb-4">
            <input type="password" name="password" placeholder="Password"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
        </div>

        <div class="mb-6">
            <select name="role" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
                <option value="">-- Pilih Role --</option>
                <option value="petugasloket">Petugas</option>
            </select>
        </div>

        <button type="submit"
            class="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-400 transition duration-200 focus:outline-none focus:ring-2 focus:ring-green-600">
            Buat Akun
        </button>
    </form>
</body>
</html>
