<?php
require_once __DIR__ . '/../Models/User.php';

class UserController {
    private $model;

    public function __construct() {
        $this->model = new User();
    }

    // ================= LOGIN =================
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if ($email === '' || $password === '') {
                $error = "Email dan password harus diisi!";
                include __DIR__ . '/../Views/Auth/login.php';
                return;
            }

            $user = $this->model->login($email, $password);

            if ($user) {
                $_SESSION['id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];

                if ($user['role'] === 'admin') {
                    header("Location: index.php?action=dashboard_admin");
                } else {
                    header("Location: index.php?action=dashboard_petugas");
                }
                exit;
            } else {
                $error = "Email atau password salah!";
                include __DIR__ . '/../Views/Auth/login.php';
            }
        } else {
            include __DIR__ . '/../Views/Auth/login.php';
        }
    }

    // ================= REGISTER =================
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $role = trim($_POST['role'] ?? 'petugasloket'); // default role

            if ($username === '' || $email === '' || $password === '') {
                $error = "Semua field harus diisi!";
                include __DIR__ . '/../Views/Auth/register.php';
                return;
            }

            if ($this->model->register($username, $email, $password, $role)) {
                header("Location: index.php?action=login");
                exit;
            } else {
                $error = "Register gagal, coba lagi!";
                include __DIR__ . '/../Views/Auth/register.php';
            }
        } else {
            include __DIR__ . '/../Views/Auth/register.php';
        }
    }

    // ================= ADMIN DASHBOARD =================
    public function index() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header("Location: index.php?action=login");
            exit;
        }

        // Ambil semua pegawai loket
        $users = $this->model->getAllPetugasLoket();
        include __DIR__ . '/../Views/Admin/dashboard.php';
    }

    public function create() {
        include __DIR__ . '/../Views/Admin/create.php';
    } 

    // ================= CREATE USER =================
    public function store() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header("Location: index.php?action=login");
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $role = trim($_POST['role'] ?? 'petugasloket');

            if ($username === '' || $email === '' || $password === '' || $role === '') {
                $error = "Semua field harus diisi!";
                include __DIR__ . '/../Views/Admin/create.php';
                return;
            }

            if ($this->model->create($username, $email, $password, $role)) {
                header("Location: index.php?action=dashboard_admin");
                exit;
            } else {
                $error = "Gagal membuat user!";
                include __DIR__ . '/../Views/Admin/create.php';
            }
        } else {
            include __DIR__ . '/../Views/Admin/create.php';
        }
    }
    public function update() {
        include __DIR__ . '/../Views/Admin/update.php';
    }
    // ================= EDIT USER =================
    public function edit() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header("Location: index.php?action=login");
            exit;
        }

        if (!isset($_GET['id'])) {
            die("ID user tidak valid!");
        }

        $id = $_GET['id'];
        $user = $this->model->getById($id);
        if (!$user) {
            die("User tidak ditemukan!");
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $role = trim($_POST['role'] ?? 'petugasloket');

            if ($username === '' || $email === '' || $role === '') {
                $error = "Semua field harus diisi!";
                include __DIR__ . '/../Views/Admin/update.php';
                return;
            }

            if ($this->model->update($id, $username, $email, $role)) {
                header("Location: index.php?action=dashboard_admin");
                exit;
            } else {
                $error = "Gagal update user!";
                include __DIR__ . '/../Views/Admin/update.php';
            }
        } else {
            include __DIR__ . '/../Views/Admin/update.php';
        }
    }

    // ================= DELETE USER =================
    public function delete() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header("Location: index.php?action=login");
            exit;
        }

        if (!isset($_GET['id'])) {
            die("ID user tidak valid!");
        }

        $id = $_GET['id'];
        $user = $this->model->getById($id);
        if (!$user) {
            die("User tidak ditemukan!");
        }

        if ($this->model->delete($id)) {
            header("Location: index.php?action=dashboard_admin");
            exit;
        } else {
            echo "Gagal menghapus user!";
        }
    }
}
