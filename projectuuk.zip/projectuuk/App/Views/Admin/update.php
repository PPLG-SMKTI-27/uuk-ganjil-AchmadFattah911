<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Petugas</title>
    <link href="/../projectuuk/Public/asset/output.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
    <form action="index.php?action=edit_user&id=<?= $user['id']; ?>" method="POST"
        class="bg-indigo-50 p-8 rounded-lg shadow-lg w-full max-w-sm">

        <h2 class="text-2xl font-bold mb-6 text-center text-gray-800">Mengubah Akun Petugas</h2>

        <div class="mb-4">
            <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($user['username']); ?>"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
        </div>

        <div class="mb-4">
            <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($user['email']); ?>"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
        </div>

        <div class="mb-6">
            <select name="role" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" required>
                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                <option value="petugasloket" <?= $user['role'] === 'petugasloket' ? 'selected' : ''; ?>>Petugas</option>
            </select>
        </div>

        <button type="submit"
            class="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-400 transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-600">
            Update User
        </button>
    </form>
</body>
</html>
