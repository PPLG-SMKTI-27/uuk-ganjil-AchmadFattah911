<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kendaraan Masuk</title>
    <link href="../../Public/asset/output.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
    <form action="index.php?action=masuk_kendaraan" method="POST" 
        class="bg-indigo-50 p-8 rounded-lg shadow-lg w-full max-w-sm">
        
        <h2 class="text-2xl font-bold mb-6 text-center text-gray-800">Kendaraan Masuk</h2>

        <div class="mb-4">
            <input type="text" name="no_plat" placeholder="Nomor Plat Kendaraan"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" />
        </div>

        <div class="mb-6">
            <select name="jk" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500">
                <option value="">-- Pilih Jenis Kendaraan --</option>
                <option value="motor">Motor (Rp 5000)</option>
                <option value="mobil">Mobil (Rp 10000)</option>
            </select>
        </div>

        <button type="submit" class="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-400 transition duration-200 focus:outline-none focus:ring-2 focus:ring-green-600">
            Tambah Kendaraan
        </button>
    </form>
</body>
</html>
