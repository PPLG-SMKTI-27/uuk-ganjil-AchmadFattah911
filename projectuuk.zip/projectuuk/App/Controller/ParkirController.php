<?php
require_once __DIR__ . '/../Models/Kendaraan.php';
require_once __DIR__ . '/../Models/TempatParkir.php';

class ParkirController {
    private $kendaraan;
    private $parkir;

    public function __construct(){
        $this->kendaraan = new Kendaraan();
        $this->parkir = new TempatParkir();
    }
    public function dashboardPetugas() {
        $data = $this->parkir->getAll();
        
        $TotalHarga = $this->parkir->totalharga();
        // atau filter khusus petugas
        include __DIR__.'/../Views/Petugas/dashboard.php';

    }

    // ======== Parkir Masuk ========
    public function masuk(){
        // Pastikan hanya petugas yang bisa mengakses
        if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'petugasloket'){
            header("Location:index.php?action=beranda");
            exit;
        }

        if($_SERVER['REQUEST_METHOD']==='POST'){
            $no_plat = trim($_POST['no_plat']);
            $jk = $_POST['jk']; // 'motor' atau 'mobil'
            $id_user = $_SESSION['id'];

            // Tentukan biaya berdasarkan jenis kendaraan
            $biaya = ($jk === 'motor') ? 5000 : 10000;

            // Buat kendaraan baru
            $id_kendaraan = $this->kendaraan->create($no_plat, $jk);

            // Masukkan ke parkir dengan biaya otomatis
            $this->parkir->masuk($id_kendaraan, $id_user, $biaya);

            header("Location:index.php?action=dashboard_petugas");
            exit;
        }

        include __DIR__.'/../Views/Petugas/masuk.php';
    }

    // ======== Parkir Keluar ========
    public function keluar(){
        if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'petugasloket'){
            header("Location:index.php?action=beranda");
            exit;
        }

        if(isset($_GET['id'])){
            $this->parkir->keluar($_GET['id']);
        }

        header("Location:index.php?action=dashboard_petugas");
        exit;
    }

    // ======== Konfirmasi Parkir ========
    public function konfirmasi(){
        if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
            header("Location:index.php?action=beranda");
            exit;
        }

        if(isset($_GET['id'])){
            $this->parkir->konfirmasi($_GET['id']);
        }

        header("Location:index.php?action=dashboard_admin");
        exit;
    }

    // ======== Dashboard ========
    public function dashboard(){
        // Hanya admin yang bisa akses
        if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
            header("Location:index.php?action=beranda");
            exit;
        }

        $data = $this->parkir->getAll();
        include __DIR__.'/../Views/Admin/dashboard.php';
    }
}
