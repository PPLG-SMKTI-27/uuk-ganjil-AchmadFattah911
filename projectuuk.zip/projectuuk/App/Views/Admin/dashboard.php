<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link href="/../projectuuk/Public/asset/output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen p-6">
    <h1 class="text-3xl font-bold mb-6">Dashboard Admin</h1>
    
    <div class="mb-6">
    <a href="index.php?action=create_user" 
        class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-400 transition">Tambah User</a>
    </div>
    
    <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
        <thead class="bg-gray-200">
            <tr>
                <th class="py-2 px-4 text-left">ID</th>
                <th class="py-2 px-4 text-left">Username</th>
                <th class="py-2 px-4 text-left">Email</th>
                <th class="py-2 px-4 text-left">Role</th>
                <th class="py-2 px-4 text-left">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr class="border-b hover:bg-gray-100">
                    <td class="py-2 px-4"><?= $user['id'] ?></td>
                    <td class="py-2 px-4"><?= $user['username'] ?></td>
                    <td class="py-2 px-4"><?= $user['email'] ?></td>
                    <td class="py-2 px-4"><?= $user['role'] ?></td>
                    <td class="py-2 px-4 space-x-2">
                        <a href="index.php?action=update_user&id=<?= $user['id'] ?>" 
                            class="px-2 py-1 bg-yellow-400 text-white rounded hover:bg-yellow-300 transition">Edit</a>
                        <a href="index.php?action=delete_user&id=<?= $user['id'] ?>" 
                            class="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-400 transition"
                            onclick="return confirm('Yakin hapus user?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
