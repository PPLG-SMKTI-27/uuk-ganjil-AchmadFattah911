<?php
require_once __DIR__ . "/../../Config/database.php";

class Kendaraan {
    private $conn;
    private $table = "kendaraan";

    public function __construct(){
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function create($no_plat, $jk){
        $query = "INSERT INTO {$this->table} (no_plat,jk) VALUES (:no_plat,:jk)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":no_plat",$no_plat);
        $stmt->bindParam(":jk",$jk);
        if($stmt->execute()){
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function getById($id){
        $query = "SELECT * FROM {$this->table} WHERE id=:id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id",$id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
