<?php
require_once __DIR__ . "/../../Config/database.php";

class User {
    private $conn;
    private $table = "users";

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    // Ambil semua user
    public function getAll() {
        $query = "SELECT * FROM {$this->table} ORDER BY id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Ambil semua pegawai loket
    public function getAllPetugasLoket() {
        $query = "SELECT * FROM {$this->table} WHERE role = 'petugasloket' ORDER BY id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Ambil user berdasarkan ID
    public function getById($id) {
        $query = "SELECT * FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Register user baru
    public function register($username, $email, $password, $role = 'petugasloket') {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO {$this->table} (username,email,password,role) VALUES (:username,:email,:password,:role)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username",$username);
        $stmt->bindParam(":email",$email);
        $stmt->bindParam(":password",$hashed);
        $stmt->bindParam(":role",$role);
        return $stmt->execute();
    }

    // Login user
    public function login($email, $password) {
        $query = "SELECT * FROM {$this->table} WHERE email=:email LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email",$email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if($user && password_verify($password,$user['password'])) return $user;
        return false;
    }

    // Create user (wrapper register)
    public function create($username,$email,$password,$role){
        return $this->register($username,$email,$password,$role);
    }

    // Update user
    public function update($id, $username, $email, $role = null){
        if ($role) {
            $query = "UPDATE {$this->table} SET username=:username, email=:email, role=:role WHERE id=:id";
        } else {
            $query = "UPDATE {$this->table} SET username=:username, email=:email WHERE id=:id";
        }

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username",$username);
        $stmt->bindParam(":email",$email);
        if ($role) $stmt->bindParam(":role",$role);
        $stmt->bindParam(":id",$id);
        return $stmt->execute();
    }

    // Delete user
    public function delete($id){
        $query = "DELETE FROM {$this->table} WHERE id=:id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id",$id);
        return $stmt->execute();
    }
}
